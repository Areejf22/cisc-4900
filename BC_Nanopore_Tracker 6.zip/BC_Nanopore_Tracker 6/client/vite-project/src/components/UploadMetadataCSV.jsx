import React, { useState } from 'react';
import axios from 'axios';
import './UploadCSV.css';

export default function UploadMetadataCSV() {
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState('');

  const handleUpload = async () => {
    if (!file) return;
  
    const formData = new FormData();
    formData.append('csv_file', file); // ✅ matches backend
  
    try {
      await axios.post('/upload-csv', formData);
      setMessage('CSV uploaded successfully!');
    } catch (err) {
      console.error(err);
      setMessage('Upload failed.');
    }
  };
  

  return (
    <div className="upload-box">
      <h2>Upload Sample Metadata (CSV)</h2>
      <input type="file" accept=".csv" onChange={e => setFile(e.target.files[0])} />
      <div className="button-group">
        <button className="upload-btn" onClick={handleUpload}>Upload</button>
      </div>
      {message && <div className="message-box">{message}</div>}
    </div>
  );
}
