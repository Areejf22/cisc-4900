import React, { useState } from 'react';
import axios from 'axios';
import './AddSampleForm.css';
 

const AddSampleForm = ({ onClose }) => {
  const [formData, setFormData] = useState({
    sample_code: '',
    experiment_code: '',
    sample_type: '',
    date_collected: '',
    location_collected_name: '',
    sample_notes: '',
    experimenter_name: '',
    extraction: '',
    date_extracted: '',
    dna_extraction_kit: '',
    dna_conc_ng_ul: '',
    extraction_notes: '',
  });

  const handleChange = e => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async e => {
    e.preventDefault();
    try {
      await axios.post('/add-sample', formData);
      alert('Sample metadata submitted!');
      onClose();
    } catch (error) {
      console.error('Submission failed:', error);
      alert('Failed to submit data.');
    }
  };

  return (
    <div className="modal">
      <form className="modal-content" onSubmit={handleSubmit}>
        <h2>Enter Sample Metadata</h2>
        {Object.keys(formData).map(key => (
          <input
            key={key}
            type="text"
            name={key}
            placeholder={key.replace(/_/g, ' ')}
            value={formData[key]}
            onChange={handleChange}
          />
        ))}
        <div className="button-group">
          <button type="submit" className="submit-button">Submit</button>
         <button type="button" className="close-button" onClick={onClose}>Close</button>
         </div>



      </form>
    </div>
  );
};

export default AddSampleForm;
