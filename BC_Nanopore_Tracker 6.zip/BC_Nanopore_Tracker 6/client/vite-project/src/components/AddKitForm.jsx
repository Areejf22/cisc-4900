import React, { useState } from 'react';
import axios from 'axios';
import './AddMinion.css'; // reuse modal styling

export default function AddKitForm({ onClose }) {
  const [kitData, setKitData] = useState({
    kit_type: '',
    date_opened: '',
    kit_owner: '',
    num_preps_expected: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
  
    // Convert numeric fields to numbers
    const parsedValue = ['num_preps_expected'].includes(name)
      ? parseInt(value, 10) || 0
      : value;
  
    setKitData((prev) => ({ ...prev, [name]: parsedValue }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('/add-kit', kitData);
      alert('Kit added!');
      onClose();
    } catch (err) {
      console.error(err);
      alert('Failed to add kit');
    }
  };

  return (
    <div className="modal">
      <form className="modal-content" onSubmit={handleSubmit}>
        <h2>Add New Kit</h2>
        {Object.keys(kitData).map((key) => (
          <input
            key={key}
            name={key}
            placeholder={key.replace(/_/g, ' ')}
            value={kitData[key]}
            onChange={handleChange}
            type={key.includes('date') ? 'date' : 'text'}
          />
        ))}
        <button type="submit">Submit</button>
        <button type="button" className="close-button" onClick={onClose}>
          Close
        </button>
      </form>
    </div>
  );
}
